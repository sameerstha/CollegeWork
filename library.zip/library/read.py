# read the list of book with details and put them in 2D lists
def items_in_2D(file_name):
    try:
        file=open(file_name,"r")
        borrowed=[]
        lines=file.readlines()
        for line in lines:
            list1=line.replace("\n","").split(",")
            borrowed.append(list1)
        file.close()
    except:
        borrowed=[]
    return borrowed


