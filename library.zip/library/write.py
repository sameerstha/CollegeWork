# write the customer details in customer text file
def write_borrowed(items,name,date_time,borrowed):
    file=open("customer.txt","w")
    for lines in borrowed:
        file.write(",".join(lines))
        file.write("\n")
    file.write(name+","+str(date_time))
    for i in range(1,len(items)):
        file.write(","+items[i][0])
    file.close()
    return
# make the new text file for each customer details
def write_individual(status,name,date_time,just_now,final):
    import read as r
    items=r.items_in_2D(name+".txt")
    file=open(name+".txt", 'w') 
    for lines in items:
        file.write(",".join(lines))
        file.write("\n")
    
    file.write(status+","+str(date_time)+","+",".join(just_now)+","+final)
    file.close()
    return
# after returning books, clearing details of customer
def write_after_returned(borrowed):
    file=open("customer.txt","w")
    for lines in borrowed:
        file.write(",".join(lines))
        file.write("\n")
    file.close()
    return
# update the number of books after transaction
def update_book_lists(book_lists):
    file=open("book_lists.txt","w")
    for line in book_lists:
        file.write(",".join(line))
        file.write("\n")
    file.close()
    return
        
