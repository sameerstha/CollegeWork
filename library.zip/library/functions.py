# asking a user to borrow & return book 
def decision_to_borrow_return(borrowed,name):
    decision=input("\nPress 'b' to borrow book and 'r' to return book: ").lower()
    while decision!= 'b' and decision!='r':
        decision=input("\nINVALID INPUT \nPress 'b' to borrow book and 'r' to return book: ").lower()
    if decision=='r':
        value=False
        for i in borrowed:
            if i[0]==name:
                value=True
        if value==False:
            print("\nSorry! You have not borrowed any books.")
            decision="end"
    return decision

# displaying books available in library
def print_data(book_lists):
    i=1
    sucess=False
    print("\nFollowing are the books that we have in our book_lists:")
    for list1 in book_lists:
        print(i,") ",list1[0])
        i=i+1
    decision=input("\nPlease enter book number shown in list above(1,2,3,4 or 5): ")
                   
    
    while sucess==False:
        try:
            book_num=int(decision)
            if book_num>0 and book_num<i:
                sucess=True
            else:
                decision=input("\nPlease enter book number shown in list above(1,2,3,4 or 5): ")
        except:
            print("\nINVALID INPUT\n")
            decision=input("Please enter book number shown in list above(1,2,3,4 or 5): ")
    return int(decision)

# displaying details of books
def display_details(item, already_borrowed,just_now):
    decision="end"
    if int(item[2])<1:
        print("\nSorry that book is out of book_lists.")
    else:
        if item[0] in already_borrowed or item[0] in just_now:
            print("\nYou cannot borrowed this book.\nYou have already borrowed this book.")
        else:
            print("\nName of the book: ", item[0])
            print("Name of the writer: ", item[1])
            print("Number of books available in book_lists: ", item[2])
            print("Price of the: ", item[3])
            decision=input("Are you sure to borrow this book?(y/n): ").lower()
            while decision!= 'y' and decision!='n':
                decision=input("INVALID INPUT \nPlease enter 'y' or 'n': ").lower()
    return decision

# taking a input to borrow another book or not
def input_y_n():
    decision=input("\nDo you want to borrow another book or not?(y/n)").lower()
    while decision!= 'y' and decision!='n':
        decision=input("INVALID INPUT \nPlease enter 'y' or 'n': ").lower()
    return decision

def already_borrowed(name,borrowed):
    already_borrowed=[]
    for list1 in borrowed:
        if name in list1:
            for index in range(2, len(list1)):
                already_borrowed.append(list1[index])
    return already_borrowed

# making a bill of transaction
def bill(already_borrowed,name,book_lists,datetime,total):
    from tabulate import tabulate
    print("----------------------------------------------------------------------------------------")
    print("Name: ",name)
    print("Date and time of transaction: ",datetime)
    list_=[["Name of the book:","Writer name:","Price:", "Date and time:"]]
    for list1 in book_lists:
        for book_name in already_borrowed:
            if book_name==list1[0]:
                list2=[]
                list2.append(book_name)
                list2.append(list1[1])
                list2.append(list1[3])
                list2.append(str(datetime))
                list_.append(list2)
    print("\n")
    print(tabulate(list_, headers="firstrow"))
    print("\nTotal price: $",total)
    
    print("\n>>>NOTE:You must return the book within 10 days. \nOtherwise you will be fined $0.5 per day for a book.")
    print("----------------------------------------------------------------------------------------")
    return list_

# returning a book
def books_to_return(already_borrowed):

    return_now=[]
    s_n=1
    for book_name in already_borrowed:
        print(s_n,") "+book_name)
        s_n+=1
    decision=input("\nWhich number book do you want to return?[If you want to return more than 1 book, then seperate the numbers with comma(,)](Eg:1,2,3...): ")
    sucess=False
    num=[]
    while sucess==False:
        try:
            decision=decision.split(",")
            for str_num in decision:
                if int(str_num)>0 and int(str_num)<len(already_borrowed)+1:
                    num.append(int(str_num))
                    sucess=True
                else:
                    print("\nPlease input the number as shown in above list")
                    decision=input("\nWhich number book do you want to return?[If you want to return more than 1 book, then seperate the numbers with comma(,)](Eg:1,2,3...): ")
                    sucess=False
                    break
        except:
            print("\nINVALID INPUT\nPlease input as instructed")
            decision=input("\nWhich number book do you want to return?[If you want to return more than 1 book, then seperate the numbers with comma(,)](Eg:1,2,3...): ")
            sucess=False
    for n in num:
        return_now.append(already_borrowed[n-1])
    return return_now

# displaying a note after returing book
def display_returned(return_now,borrowed,date_time,name):
    from tabulate import tabulate
    import datetime
    tot_fine=0.0
    display=[["Name of book:","Date time(borrowed):","Date time(returned):", "FINE:"]]
    for line in borrowed:        
        if line[0]==name:
            for index in range(2,len(line)):
                list1=[]
                fine=0.0
                if line[index] in return_now:
                    list1.append(line[index])
                    list1.append(line[1])
                    list1.append(str(date_time))
                    d_t=line[1].split(" ")
                    date=d_t[0].split("-")
                    time=d_t[1].split(":")
                    year=int(date[0])
                    month=int(date[1])
                    day=int(date[2])
                    hour=int(time[0])
                    minute=int(time[1])
                    sec=int(time[2])
                    borrowed_date=datetime.datetime(year,month,day,hour,minute,sec)
                    num_days_took=date_time-borrowed_date
                    if int(num_days_took.days)>10:
                        fine_day= int(num_days_took.days)-10
                        fine=fine+ float(fine_day)*0.5
                    tot_fine=tot_fine+fine
                    list1.append("$"+str(fine))
                    display.append(list1)
    print("----------------------------------------------------------------------------------------")
    print(tabulate(display, headers="firstrow"))
    return tot_fine

# function for book after returning
def item_after_return(borrowed,return_now,name):
    for line in borrowed:
        if line[0]==name:
            for book in return_now:
                if book in line:
                    line.remove(book)
            if len(line)==2:
                borrowed.remove(line)
    return borrowed

# decreasing number of book in text file
def reduce_book_lists(book_lists,borrowed_now):
    for book in borrowed_now:
        for list1 in book_lists:
            if book==list1[0]:
                list1[2]=str(int(list1[2])-1)
    return book_lists

# increasing number of book in text file
def increase_book_lists(book_lists,return_now):
    for book in return_now:
        for list1 in book_lists:
            if book==list1[0]:
                list1[2]=str(int(list1[2])+1)
    return book_lists
        
            
            
                
                
        
    

                
    
        
                
    
        
