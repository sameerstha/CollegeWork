print("\t\tWELCOME TO BOOKSTORE\n\tLIBRARY MANAGEMENT SYSTEM OF BOOKSTORE\n")

import datetime
import functions as functions
import read as read
import write as write


new_customer = "y"
# making a loop to run if there is any other customer after doing transaction with a person
while new_customer.lower() == "y":
    name=input("Enter the name of customer: ").lower()                       # asking user to input name of customer
    borrowed=read.items_in_2D("customer.txt")                                # storing text fle in a variable
    book_lists=read.items_in_2D("book_lists.txt")                            # storing text fle in a variable
    total=0.0
    decision=functions.decision_to_borrow_return(borrowed,name)
    already_borrowed=functions.already_borrowed(name,borrowed)
    borrowed_now=[]
    answer='y'
    date_time=datetime.datetime.now().replace(microsecond=0)
    borrowed_value=False
    if decision=='b':                                                         # condition to run if customer wants to borrow book
        while answer=='y':
            num=functions.print_data(book_lists)
            conform=functions.display_details(book_lists[num-1],already_borrowed,borrowed_now)
            if conform=='y':
                borrowed_now.append(book_lists[num-1][0])
                borrowed_value=True
                total=total+float(book_lists[num-1][-1].replace("$",""))
            answer=functions.input_y_n()
        
    elif decision=='r':                                                       # condition to run if customer wants to return book
        return_now=functions.books_to_return(already_borrowed)
        fine=functions.display_returned(return_now,borrowed,date_time,name)
        print("\nTotal fine= $",fine)
        print("----------------------------------------------------------------------------------------")
        borrowed=functions.item_after_return(borrowed,return_now,name)
        functions.increase_book_lists(book_lists,return_now)
        write.write_after_returned(borrowed)
        write.write_individual("RETURNED",name,date_time,return_now,"Fine Paid: $"+str(fine))
    if borrowed_value==True:                                                   # condition to update the text files
        functions.reduce_book_lists(book_lists,borrowed_now)
        items_borrowed=functions.bill(borrowed_now,name,book_lists,date_time,total)
        write.write_borrowed(items_borrowed,name,date_time,borrowed)
        write.write_individual("BORROWED",name,date_time,borrowed_now,"Total Paid: $"+str(total))
    write.update_book_lists(book_lists)
    new_customer = input("New Customer? y/n")               # asking is there any new customer or not
        
        
