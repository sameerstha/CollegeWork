SQL> SELECT * FROM PATIENT;

PATIENT_ID PATIENT_NAME                   PATIENT_CATEGOR PATIENT_D                                                                                                                                     
---------- ------------------------------ --------------- ---------                                                                                                                                     
P1         Sita Adhikari                  new             11-FEB-03                                                                                                                                     
P2         Amir Stha                      regular         13-NOV-06                                                                                                                                     
P3         Om Raj Yadav                   new             11-JAN-05                                                                                                                                     
S4         Hari K.C.                      regular         26-JAN-00                                                                                                                                     
S5         Sita Yadav                     new             07-DEC-00                                                                                                                                     
S6         Raju Thapa                     regular         08-NOV-00                                                                                                                                     
S7         Kim John                       new             21-JAN-00                                                                                                                                     

7 rows selected.

SQL> SELECT * FROM PATIENT
  2  WHERE Patient_Category = 'new';

PATIENT_ID PATIENT_NAME                   PATIENT_CATEGOR PATIENT_D                                                                                                                                     
---------- ------------------------------ --------------- ---------                                                                                                                                     
P1         Sita Adhikari                  new             11-FEB-03                                                                                                                                     
P3         Om Raj Yadav                   new             11-JAN-05                                                                                                                                     
S5         Sita Yadav                     new             07-DEC-00                                                                                                                                     
S7         Kim John                       new             21-JAN-00                                                                                                                                     

SQL> SELECT * FROM PATIENT
  2  WHERE Patient_Category = 'regular';

PATIENT_ID PATIENT_NAME                   PATIENT_CATEGOR PATIENT_D                                                                                                                                     
---------- ------------------------------ --------------- ---------                                                                                                                                     
P2         Amir Stha                      regular         13-NOV-06                                                                                                                                     
S4         Hari K.C.                      regular         26-JAN-00                                                                                                                                     
S6         Raju Thapa                     regular         08-NOV-00                                                                                                                                     

SQL> SPOOL OFF;
