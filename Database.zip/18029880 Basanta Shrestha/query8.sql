SQL> SELECT p.Patient_Id, p.Patient_Name,ap.Appointment_Id "Appoint_Id",  ap.APPOINTMENT_Date
  2  FROM PATIENT p JOIN STAFFPATIENTAPPOINTMENT spa ON p.Patient_Id = spa.Patient_Id
  3  JOIN APPOINTMENT ap ON (spa.Appointment_Id=ap.Appointment_Id);

PATIENT_ID PATIENT_NAME                   Appoint_Id APPOINTME                                                                                                                                          
---------- ------------------------------ ---------- ---------                                                                                                                                          
P1         Sita Adhikari                  AP1        30-OCT-19                                                                                                                                          
P2         Amir Stha                      AP2        01-NOV-19                                                                                                                                          
P2         Amir Stha                      AP3        14-NOV-19                                                                                                                                          
P2         Amir Stha                      AP4        15-NOV-19                                                                                                                                          
P3         Om Raj Yadav                   AP5        11-NOV-19                                                                                                                                          
S4         Hari K.C.                      AP6        26-NOV-19                                                                                                                                          
S4         Hari K.C.                      AP7        27-NOV-19                                                                                                                                          
S5         Sita Yadav                     AP8        06-NOV-19                                                                                                                                          
S6         Raju Thapa                     AP9        07-NOV-19                                                                                                                                          
S6         Raju Thapa                     AP10       08-NOV-19                                                                                                                                          
S7         Kim John                       AP11       20-NOV-19                                                                                                                                          

11 rows selected.

SQL> SPOOL OFF;
