SQL> SELECT ap.Appointment_Id "Appoint_Id", w.Ward_Id, w.Ward_Name, w.Ward_Type
  2  FROM APPOINTMENT ap JOIN WARD w ON (ap.Ward_Id=w.Ward_Id)
  3  WHERE w.Ward_Type = 'Emergency';

Appoint_Id    WARD_ID WARD_NAME                 WARD_TYPE                                                                                                                                               
---------- ---------- ------------------------- -------------------------                                                                                                                               
AP1                 1 Cardiology                Emergency                                                                                                                                               
AP7                 4 Pathology                 Emergency                                                                                                                                               
AP8                 4 Pathology                 Emergency                                                                                                                                               
AP9                 5 Physiotherapy             Emergency                                                                                                                                               
AP11                7 Orthopaedics              Emergency                                                                                                                                               

SQL> SPOOL OFF;
