SQL> SELECT p.Patient_Id "Staff_Id", p.Patient_Name "Staff_Name"
  2  FROM Patient p JOIN StaffPatientDetail spd ON (spd.Patient_Id= p.Patient_Id)
  3  JOIN Staff s ON (s.Staff_Id=spd.Staff_Id)
  4  WHERE p.Patient_Id LIKE 'S%';

Staff_Id   Staff_Name                                                                                                                                                                                   
---------- ------------------------------                                                                                                                                                               
S4         Hari K.C.                                                                                                                                                                                    
S5         Sita Yadav                                                                                                                                                                                   
S6         Raju Thapa                                                                                                                                                                                   
S7         Kim John                                                                                                                                                                                     

SQL> SPOOL OFF;
