SQL> SELECT s.Staff_Id, ap.Appointment_Id "Appoint_Id", s.Staff_Name, s.Staff_Type, s.Staff_Category, ap.Appointment_Charge
  2  FROM Staff s JOIN StaffPatientAppointment spa ON (s.Staff_Id=spa.Staff_Id)
  3  JOIN Appointment ap ON (spa.Appointment_Id=ap.Appointment_Id)
  4  WHERE s.Staff_Category='Certified' AND s.Staff_Type = 'Doctor';

STAFF_ID   Appoint_Id STAFF_NAME                     STAFF_TYPE      STAFF_CATEGORY  APPOINTMENT_CHARGE                                                                                                 
---------- ---------- ------------------------------ --------------- --------------- ------------------                                                                                                 
S1         AP1        Sameer Stha                    Doctor          Certified                     4000                                                                                                 
S1         AP2        Sameer Stha                    Doctor          Certified                     4000                                                                                                 
S1         AP3        Sameer Stha                    Doctor          Certified                     3500                                                                                                 
S1         AP4        Sameer Stha                    Doctor          Certified                     3500                                                                                                 

SQL> SPOOL OFF;
