SQL> SELECT p.Patient_Id, p.Patient_Name, a.Patient_Country, a.Patient_Province, a.Patient_City, a.Patient_Street, a.Patient_StreetNumber
  2  FROM PATIENT p JOIN PATIENTADDRESSDETAIL pa
  3  ON p.Patient_Id = pa.Patient_Id
  4  JOIN PATIENTADDRESS a
  5  ON a.PatientAddress_Id = pa.PatientAddress_Id;

PATIENT_ID PATIENT_NAME                   PATIENT_COUNTRY      PATIENT_PROVINCE     PATIENT_CITY         PATIENT_STREET       PATIENT_STREETNUMBER                                                      
---------- ------------------------------ -------------------- -------------------- -------------------- -------------------- --------------------                                                      
P1         Sita Adhikari                  Nepal                Bagmati              Kathmandu            Jyatha Street                           2                                                      
P1         Sita Adhikari                  Nepal                Bagmati              Kathmandu            Minbhawan                               1                                                      
P2         Amir Stha                      Nepal                Gandaki              Pokhara              Phewa                                   2                                                      
P2         Amir Stha                      Nepal                Bagmati              Kathmandu            Babarmahal                              1                                                      
P3         Om Raj Yadav                   Nepal                Bagmati              Kathmandu            Putalisadak                             4                                                      
S4         Hari K.C.                      Nepal                Bagmati              Suryabinayak         Biruwa                                  2                                                      
S5         Sita Yadav                     Nepal                Bagmati              Kathmandu            Minbhawan                               3                                                      
S6         Raju Thapa                     Nepal                Mechi                Damak                Pathari                                 1                                                      
S7         Kim John                       Nepal                Karnali              Birendranagar        Buddha Path                             1                                                      

9 rows selected.

SQL> SPOOL OFF;
