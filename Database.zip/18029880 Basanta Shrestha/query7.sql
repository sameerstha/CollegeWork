SQL> SELECT p.Patient_Id "Staff_Id", p.Patient_Name "Staff_Name", s.Staff_Category, ap.Appointment_Id "Appoint_Id", ap.Appointment_Date
  2  FROM STAFF s JOIN STAFFPATIENTAPPOINTMENT spa ON (spa.Staff_Id = s.Staff_Id)
  3  JOIN APPOINTMENT ap ON (spa.Appointment_Id=ap.Appointment_Id)
  4  JOIN Patient p ON (spa.Patient_Id= p.Patient_Id)
  5  Where p.Patient_Id LIKE 'S%';

Staff_Id   Staff_Name                     STAFF_CATEGORY  Appoint_Id APPOINTME                                                                                                                          
---------- ------------------------------ --------------- ---------- ---------                                                                                                                          
S4         Hari K.C.                      UnCertified     AP6        26-NOV-19                                                                                                                          
S4         Hari K.C.                      UnCertified     AP7        27-NOV-19                                                                                                                          
S5         Sita Yadav                     Certified       AP8        06-NOV-19                                                                                                                          
S6         Raju Thapa                     Certified       AP9        07-NOV-19                                                                                                                          
S6         Raju Thapa                     Certified       AP10       08-NOV-19                                                                                                                          
S7         Kim John                       Certified       AP11       20-NOV-19                                                                                                                          

6 rows selected.

SQL> SPOOL OFF;
