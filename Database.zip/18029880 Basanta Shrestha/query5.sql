SQL> SELECT p.Patient_Id "Staff_Id", p.Patient_Name "Staff_Name", ap.Appointment_Id "Appoint_Id", ap.Appointment_Charge
  2  FROM PATIENT p JOIN  StaffPatientAppointment spa ON (p.Patient_Id=spa.Patient_Id)
  3  JOIN Appointment ap ON (spa.Appointment_Id=ap.Appointment_Id)
  4  WHERE p.Patient_Id LIKE 'S%' AND Appointment_Charge != 0;

Staff_Id   Staff_Name                     Appoint_Id APPOINTMENT_CHARGE                                                                                                                                 
---------- ------------------------------ ---------- ------------------                                                                                                                                 
S6         Raju Thapa                     AP9                      4000                                                                                                                                 
S6         Raju Thapa                     AP10                     4000                                                                                                                                 
S7         Kim John                       AP11                     3500                                                                                                                                 

SQL> SPOOL OFF;
